#pragma once

#include "Data/DataRecordModels.h"
#include "Modules/ModuleRegistry.h"
#include <string>
#include <unordered_map>
#include <vector>

class DataRegistry
{
public:
    bool Initialize(const std::string& DataRoot);
    void Shutdown();

    const std::vector<ModuleDefinition>& GetLoadedModuleDefinitions() const;
    const std::vector<ItemDefinition>& GetLoadedItemDefinitions() const;
    const std::vector<RecipeDefinition>& GetLoadedRecipeDefinitions() const;
    const std::vector<MissionDefinition>& GetLoadedMissionDefinitions() const;
    const std::vector<FactionDefinition>& GetLoadedFactionDefinitions() const;
    const std::vector<LootTableDefinition>& GetLoadedLootDefinitions() const;
    const std::vector<PlayerDefinition>& GetLoadedPlayerDefinitions() const;

    const ItemDefinition* FindItemDefinition(const std::string& Id) const;
    const RecipeDefinition* FindRecipeDefinition(const std::string& Id) const;
    const MissionDefinition* FindMissionDefinition(const std::string& Id) const;
    const FactionDefinition* FindFactionDefinition(const std::string& Id) const;
    const LootTableDefinition* FindLootDefinition(const std::string& Id) const;
    const PlayerDefinition* FindPlayerDefinition(const std::string& Id) const;

private:
    bool LoadModuleDefinitions(const std::string& Directory);
    bool LoadItemDefinitions(const std::string& Directory);
    bool LoadRecipeDefinitions(const std::string& Directory);
    bool LoadMissionDefinitions(const std::string& Directory);
    bool LoadFactionDefinitions(const std::string& Directory);
    bool LoadLootDefinitions(const std::string& Directory);
    bool LoadPlayerDefinitions(const std::string& Directory);
    void LogSummary() const;

    std::vector<ModuleDefinition> ModuleDefinitions;
    std::vector<ItemDefinition> ItemDefinitions;
    std::vector<RecipeDefinition> RecipeDefinitions;
    std::vector<MissionDefinition> MissionDefinitions;
    std::vector<FactionDefinition> FactionDefinitions;
    std::vector<LootTableDefinition> LootDefinitions;
    std::vector<PlayerDefinition> PlayerDefinitions;

    std::unordered_map<std::string, std::size_t> ItemIndexById;
    std::unordered_map<std::string, std::size_t> RecipeIndexById;
    std::unordered_map<std::string, std::size_t> MissionIndexById;
    std::unordered_map<std::string, std::size_t> FactionIndexById;
    std::unordered_map<std::string, std::size_t> LootIndexById;
    std::unordered_map<std::string, std::size_t> PlayerIndexById;
};
