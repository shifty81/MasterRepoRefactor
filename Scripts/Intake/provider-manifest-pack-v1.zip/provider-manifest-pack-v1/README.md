# Provider Manifest Pack v1 - Compile Scaffold

This pack is a compile-oriented scaffold for a manifest-driven provider system in a standalone WPF server deployment and management application.

It includes:
- C# manifest contracts and enums
- Registry, loader, inheritance, defaults, conditions, validation, and output mapping services
- Sample WPF MVVM dynamic config page scaffold
- Sample manifests and provider registry
- Sample JSON schema

This pack is intentionally lean but structured so you can drop it into a solution and expand it without rewriting the core architecture.
