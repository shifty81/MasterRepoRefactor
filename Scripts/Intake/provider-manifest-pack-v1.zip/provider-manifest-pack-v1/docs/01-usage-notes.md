# Usage Notes

1. Register manifest services with the registry path and manifest root.
2. Load a manifest by provider id.
3. Build default state.
4. Feed the resolved manifest into `DynamicConfigPageViewModel`.
5. Bind `DynamicConfigPage.xaml` to that view model.
6. On save or deploy, call `IManifestValidationEngine` and `IManifestOutputMapper`.

## Intended next extensions
- Replace placeholder schema validation with full JSON Schema validation.
- Add richer WPF controls for Folder/File, KeyValue, and JSON.
- Add provider-specific argument builders.
- Add persistence and config migration.
