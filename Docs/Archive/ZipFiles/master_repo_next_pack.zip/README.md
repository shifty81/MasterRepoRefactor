# Master Repo Next Pack

Contents:
- `docs/EXPANDED_BUILDER_SALVAGE_SPEC.md`
- `docs/EXPANDED_SAVELOAD_CONTRACTS.md`
- `docs/EXPANDED_ARBITER_COMMAND_GATEWAY.md`
- `code/Runtime/BuilderRuntime/*`
- `code/Runtime/Salvage/*`
- `code/Runtime/SaveLoad/*`
- `code/Runtime/Gameplay/BuilderSalvageRuntimeBridge.*`
- `code/Runtime/Debug/RuntimeDebugCommandService.*`
- `arbiter/*`

Use this pack to extend the earlier runtime gameplay pack with the next integration layer:
1. Builder + Salvage runtime
2. Save/load deterministic persistence
3. Arbiter command gateway definitions
