# Arbiter ↔ NovaForge starter files

This bundle contains a clean first-pass scaffold for the integration boundary.

## Included
- `novaforge/novaforge.project.json`
- `novaforge/integrations/arbiter/include/ArbiterBridgeTypes.h`
- `novaforge/integrations/arbiter/include/ArbiterBridgeService.h`
- `novaforge/integrations/arbiter/src/ArbiterBridgeService.cpp`
- `arbiter/ProjectAdapters/NovaForge/NovaForgeProjectManifest.cs`
- `arbiter/ProjectAdapters/NovaForge/NovaForgeProjectAdapter.cs`

## Intent
These files are intentionally lightweight. They establish:
- a project manifest
- a C++ bridge contract on the NovaForge side
- a minimal bridge service stub
- a C# adapter on the Arbiter side

## Recommended next steps
1. Wire `FArbiterBridgeService::RunBuild` into your actual build runner.
2. Add your real editor-selection query.
3. Implement a safe tool action registry with an allowlist.
4. Add auth or local-trust safeguards before enabling write actions.
5. Route these through your chosen transport layer.
