# MasterRepo T1–T3 Editor Foundation Pack

This pack covers the first three tooling phases:

- T1: Editor core foundation
- T2: Scene outliner + property inspector
- T3: Gizmo + transform foundation

## Included
- editor mode controller
- editor input router
- free/orbit camera controller shell
- selection system scaffold
- scene outliner data model
- property inspector scaffold
- gizmo system base
- starter editor config
- implementation roadmap

## Goal
Provide the first usable editor shell so the project can:
- switch between game and editor modes
- select world objects
- inspect object state
- prepare for transform editing
