#pragma once

#include "Editor/Inspector/InspectorTypes.h"
#include "Editor/Selection/SelectionSystem.h"

class PropertyInspector
{
public:
    bool Initialize();
    void InspectSelection(const SelectionSystem& Selection);
    const InspectorState& GetState() const;

private:
    InspectorState State;
};
