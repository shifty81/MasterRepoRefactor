#pragma once

#include "Editor/Gizmos/GizmoTypes.h"
#include "Editor/Selection/SelectionSystem.h"

class GizmoSystem
{
public:
    bool Initialize();
    void UpdateFromSelection(const SelectionSystem& Selection);
    void SetToolMode(EEditorToolMode Mode);
    void SetLocalMode(bool bEnabled);
    void SetSnapEnabled(bool bEnabled);

    const GizmoState& GetState() const;

private:
    GizmoState State;
};
