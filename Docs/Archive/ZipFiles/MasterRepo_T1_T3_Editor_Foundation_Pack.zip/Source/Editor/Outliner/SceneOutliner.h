#pragma once

#include "Editor/Outliner/OutlinerTypes.h"
#include "Editor/Selection/SelectionSystem.h"

class SceneOutliner
{
public:
    bool Initialize();
    void RebuildFromSelectionSystem(const SelectionSystem& Selection);
    const SceneOutlinerState& GetState() const;

private:
    SceneOutlinerState State;
};
