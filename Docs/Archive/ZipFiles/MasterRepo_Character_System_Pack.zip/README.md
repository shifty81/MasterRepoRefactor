# MasterRepo Character System Pack

This pack adds a modular low-poly character framework aligned with the Master Repo visual direction.

## Included
- modular character data types
- body part / socket / equipment scaffolding
- animation state model
- FPS / EVA / Mech mode character controller shell
- mech possession bridge scaffold
- starter character/equipment/animation definition files
- roadmap and expected-result docs

## Goal
Support low-poly modular characters similar to segmented mannequin-style rigs:
- readable silhouettes
- swappable parts
- equipment-driven visual upgrades
- FPS, EVA, and mech transfer compatibility
