# MasterRepo first-pass monorepo files

Included:
- Root `CMakeLists.txt`
- `cmake/Options.cmake`
- `Shared/CMakeLists.txt`
- `Shared/ArbiterBridgeContract/CMakeLists.txt`
- `Atlas/CMakeLists.txt`
- `NovaForge/CMakeLists.txt`
- `NovaForge/Integrations/Arbiter/CMakeLists.txt`

Notes:
- This is a first-pass wiring skeleton, not a finished build system.
- Atlas and NovaForge are represented as placeholder INTERFACE targets for safe early integration.
- `NovaForgeClient` and `NovaForgeServer` are minimal stub executables so target wiring is concrete.
- `NovaForgeIntegrationArbiter` is editor-gated and optional.
- Shipping builds can disable Arbiter integration through `NOVAFORGE_SHIPPING_BUILD=ON`.
