# Platform Hardening Implementation Pack v2

This pack is a self-contained C++17 scaffold for Atlas Suite / NovaForge platform hardening.

It includes:
- Session Authority
- Capability Resolver
- Path Policy Service
- Audit Event Writer
- Archive Intake Service
- Command Broker
- Bridge Service
- sample JSON configs
- lightweight tests

## Design goals
- local-first
- default deny
- capability-based writes
- audited mutations
- root-drop archive quarantine
- no arbitrary shell execution

## Intended placement
Drop these folders into the repo root or merge them into the matching Atlas service locations.

## Integration notes
- The code is standard-library only.
- JSON parsing is intentionally lightweight and schema-specific so the module stays dependency-free.
- File hashing uses FNV-1a 64-bit for deterministic intake IDs. Replace with SHA-256 later if you want stronger tamper detection.
- `BridgeService` is transport-agnostic. You can wire it to named pipes, loopback HTTP, or your existing bridge transport.

## Suggested repo mapping
- `src/security/*` -> `Atlas/Services/Security/*`
- `src/archive/*` -> `Atlas/Services/Archive/*`
- `src/bridge/*` -> `Atlas/Services/Bridge/*`
- `config/*` -> `Config/Security/*`
- `tests/*` -> `Tests/Security/*`

## Build
```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```
