# Master Repo Split Docs Pack

This pack contains:

- Repo-ready Markdown docs split by system
- Cross-linked architecture references
- ASCII diagrams for core flows
- `autodoc_generator.py` for turning JSON schemas into Markdown docs
- `compliance_scanner.py` for scanning a repo against Master Repo standards

## Suggested repo layout

- `Docs/` → copy into your repo docs folder
- `Tools/Arbiter/` → tool-side documentation helpers
- `Tools/Compliance/` → repo compliance audit helpers

## Recommended integration flow

1. Put `Docs/` into the repo.
2. Point Arbiter at `Docs/INDEX.md` as the main source entry.
3. Run the compliance scanner from repo root.
4. Generate schema docs into `Docs/Generated/` with the autodoc generator.

## Main entry points

- [Docs Index](Docs/INDEX.md)
- [Implementation Roadmap](Docs/Implementation_Roadmap.md)
- [Compliance Rules](Docs/Compliance_Rules.md)
