# Master Repo Split Docs Pack

This pack is a clean, repo-ready documentation layer for the current **MasterRepo** tree.

It is organized as:
- one Markdown file per major system
- a shared project standard
- cross-links between docs
- embedded ASCII diagrams
- an **Arbiter Auto-Doc Generator**
- a **Compliance Scanner** that checks the repo against the documented standard

## Pack layout

- [Project Standard](./standards/MASTER_PROJECT_STANDARD.md)
- [System Index](./systems/README.md)
- [Arbiter / AI](./systems/AI_ARBITER.md)
- [Core](./systems/CORE.md)
- [Engine](./systems/ENGINE.md)
- [Editor](./systems/EDITOR.md)
- [Builder](./systems/BUILDER.md)
- [PCG](./systems/PCG.md)
- [Runtime + Projects](./systems/RUNTIME_AND_PROJECTS.md)
- [Tools + Agents](./systems/TOOLS_AND_AGENTS.md)
- [Archive + Legacy](./systems/ARCHIVE_AND_LEGACY.md)
- [Config + Data Schemas](./systems/CONFIG_AND_SCHEMAS.md)
- [Delivery Roadmap](./roadmap/IMPLEMENTATION_ROADMAP.md)

## Automation

- [Arbiter Auto-Doc Generator](./tools/arbiter_doc_generator/README.md)
- [Compliance Scanner](./tools/compliance_scanner/README.md)

## Current repo anchors

These pack files were scaffolded against the current repository structure:
- `.github`
- `AI`
- `Agents`
- `Archive`
- `Builder`
- `Config`
- `Core`
- `Docs`
- `Editor`
- `Engine`
- `Experiments`
- `External`
- `IDE`
- `Logs`
- `PCG`
- `Plugins`
- `Projects`
- `Runtime`
- `Scripts`
- `Tests`
- `Tools`
- `TrainingData`
- `UI`
- `Versions`
- `WorkspaceState`

## Notes

This pack reflects the project direction already established in planning:
- hybrid **voxel + low-poly** project direction
- the player suit is called a **rig**
- seasons are configurable on client and server, with server enforcement preferred
- custom project UI direction instead of introducing ImGui into project-facing UI

It is intentionally opinionated so the compliance scanner has something concrete to validate.
