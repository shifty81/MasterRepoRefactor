#pragma once

class ToolingSubsystem
{
public:
    bool Initialize();
    void Tick(float DeltaTime);
    void Shutdown();
    void ToggleOverlay();
    bool IsOverlayEnabled() const;

private:
    bool bOverlayEnabled = false;
};
