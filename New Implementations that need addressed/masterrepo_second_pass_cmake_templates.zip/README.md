# MasterRepo second-pass CMake templates

This archive provides a more realistic monorepo CMake layout than the first-pass skeleton.

Included:
- Root and shared CMake files
- Atlas module CMake files
- NovaForge module CMake files
- Optional Arbiter integration module
- Client/server executable templates
- Test target template
- Minimal bridge contract/header stubs

Use this as the next migration layer:
1. map current repo files into the module source lists
2. verify target boundaries
3. keep Arbiter optional
4. keep shipping targets isolated
