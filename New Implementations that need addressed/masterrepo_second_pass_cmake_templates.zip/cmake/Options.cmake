option(MASTERREPO_BUILD_TESTS "Build repo tests" ON)
option(MASTERREPO_BUILD_TOOLS "Build developer tools" ON)
option(MASTERREPO_BUILD_EDITOR "Build editor targets" ON)
option(MASTERREPO_BUILD_CLIENT "Build client targets" ON)
option(MASTERREPO_BUILD_SERVER "Build server targets" ON)

option(ATLAS_ENABLE_EDITOR "Enable Atlas editor systems" ON)
option(NOVAFORGE_ENABLE_ARBITER_INTEGRATION "Enable NovaForge Arbiter bridge integration" ON)
option(NOVAFORGE_SHIPPING_BUILD "Configure NovaForge as a shipping build" OFF)

if(NOVAFORGE_SHIPPING_BUILD)
    set(NOVAFORGE_ENABLE_ARBITER_INTEGRATION OFF CACHE BOOL "Disable Arbiter integration in shipping builds" FORCE)
endif()
