# Training Data

AtlasAI ingests:
- code
- configs
- docs
- assets
