# EDITOR

System documentation placeholder.

Expand with full spec.
