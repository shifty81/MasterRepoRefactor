# CONFIG_AND_SCHEMAS

System documentation placeholder.

Expand with full spec.
