# AtlasAI

Central orchestrator:
- planning
- repo analysis
- code generation
- multi-agent execution
