# Economy System

- faction driven
- mission rewards
- resource loops
