# Player Rig System

- Suit = rig
- oxygen + power routing
- tether system
- EVA support
