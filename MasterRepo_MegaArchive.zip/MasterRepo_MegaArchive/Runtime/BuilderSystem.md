# Builder System

- voxel + modular hybrid
- snap system
- damage + repair propagation
