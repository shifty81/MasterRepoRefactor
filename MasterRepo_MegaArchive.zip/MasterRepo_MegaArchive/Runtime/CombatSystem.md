# Combat System

- projectile + damage
- breach + fire simulation
